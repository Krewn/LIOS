#pragma once
#include "cinder/CinderResources.h"

#define RES_PARTICLE		CINDER_RESOURCE( ../resources/, particle.png, 128, PNG )

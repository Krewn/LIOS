// This is an auto-generated file to redirect any included
// module headers to the correct external folder.

#include "../../../../../modules/juce_core/juce_core.h"


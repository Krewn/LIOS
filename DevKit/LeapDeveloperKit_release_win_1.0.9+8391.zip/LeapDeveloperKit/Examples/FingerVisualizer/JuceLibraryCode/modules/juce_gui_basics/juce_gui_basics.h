// This is an auto-generated file to redirect any included
// module headers to the correct external folder.

#include "../../../../ThirdParty/JUCE/modules/juce_gui_basics/juce_gui_basics.h"

